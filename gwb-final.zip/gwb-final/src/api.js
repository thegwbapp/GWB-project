export const CLOUDINARY_CLOUD = "dwhjqqkjg";
export const CLOUDINARY_PRESET = "tsuduljg";

async function airtable(method, table, { formula, id, fields } = {}) {
  try {
    const res = await fetch("/.netlify/functions/airtable", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ method, table, formula, id, fields }),
    });
    return await res.json();
  } catch (e) {
    console.error("API error:", e);
    return { error: e.message };
  }
}

export async function atGet(table, formula = "") {
  const data = await airtable("GET", table, { formula });
  if (data.error) { console.error("atGet error:", table, data); return []; }
  return data.records || [];
}

export async function atPost(table, fields) {
  const data = await airtable("POST", table, { fields });
  if (data.error) { console.error("atPost error:", table, data); return null; }
  return data.records?.[0] || null;
}

export async function atPatch(table, id, fields) {
  const data = await airtable("PATCH", table, { id, fields });
  if (data.error) console.error("atPatch error:", table, data);
}

export async function atDelete(table, id) {
  await airtable("DELETE", table, { id });
}

export async function uploadImage(file) {
  try {
    const fd = new FormData();
    fd.append("file", file);
    fd.append("upload_preset", CLOUDINARY_PRESET);
    const res = await fetch(
      `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD}/image/upload`,
      { method: "POST", body: fd }
    );
    const data = await res.json();
    return data.secure_url || null;
  } catch { return null; }
}
