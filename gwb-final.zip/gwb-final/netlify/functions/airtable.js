const BASE_ID = "appb5wuLcUAajzQIv";
const API_KEY = "patwn6YwXUkSGhFpP.31855b939ac44c19aa7e96863a16c8fcb4c9bbce1cef4b3b17db823af8054c96";
const AT = `https://api.airtable.com/v0/${BASE_ID}`;

exports.handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, POST, PATCH, DELETE, OPTIONS",
    "Content-Type": "application/json",
  };

  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }

  try {
    const { method, table, formula, id, fields } = JSON.parse(event.body || "{}");

    let url = `${AT}/${encodeURIComponent(table)}`;
    if (id) url += `/${id}`;
    if (formula) url += `?filterByFormula=${encodeURIComponent(formula)}`;

    const res = await fetch(url, {
      method: method || "GET",
      headers: {
        "Authorization": `Bearer ${API_KEY}`,
        "Content-Type": "application/json",
      },
      body: fields ? JSON.stringify({ records: [{ fields }] }) : undefined,
    });

    const data = await res.json();
    return { statusCode: 200, headers, body: JSON.stringify(data) };
  } catch (e) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: e.message }) };
  }
};
